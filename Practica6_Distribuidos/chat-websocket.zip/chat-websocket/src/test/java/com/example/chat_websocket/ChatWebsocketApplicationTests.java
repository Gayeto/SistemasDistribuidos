package com.example.chat_websocket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatWebsocketApplicationTests {

	@Test
	void contextLoads() {
	}

}
